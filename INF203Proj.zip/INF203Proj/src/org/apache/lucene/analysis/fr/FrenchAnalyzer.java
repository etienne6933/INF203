package org.apache.lucene.analysis.fr;

public class FrenchAnalyzer {

}
