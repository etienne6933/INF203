package Jena_Projet;
import java.util.Date;
import java.util.Iterator;

import org.apache.jena.ontology.Individual;
import org.apache.jena.ontology.OntClass;
import org.apache.jena.ontology.OntModel;
import org.apache.jena.ontology.OntModelSpec;
import org.apache.jena.ontology.OntProperty;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Resource;
import org.apache.jena.reasoner.ValidityReport;
import org.apache.jena.vocabulary.OWL;
import org.apache.jena.vocabulary.RDFS;

public class Jena_inference {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final String	SOURCE		= "./Data/";	
		final String	WINE_NS	= "http://www.w3.org/TR/2003/PR-owl-guide-20031209/wine#";
		
		System.out.println("Etienne-Jena inference");
	
	//cr�ation et chargement du mod�le base
	System.out.println("Cr�ation et chargement du mod�le base\n");
	OntModel base = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
	base.read(SOURCE + "wine.rdf", "RDF/XML");
	
	//on cr�e un mod�le de raisonnement en utilisant le mod�le base
	System.out.println("Cr�ation du mod�le en utilisant base\n");
	OntModel inf = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM_MICRO_RULE_INF, base);
	//OWL_MEM_MICRO_RULE_INF : fonctionne assez rapidement
	
	System.out.println("----Individuals pour le test----\n");
		//Indivividuals pourle test
	
	// Instantiation de la classe pour le test
	OntClass monvin = base.getOntClass(WINE_NS+"RedBordeaux");
	
			/*
			 * D�but test de validit�
			*/
			
			System.out.println("\n--D�but test de validit� individu--\n");
			checkValidity(inf);
			
	
		//cr�ation d'un nouvel individual pour faire le test
		Individual EtienneVin = base.createIndividual(WINE_NS + "MyPinard", monvin);
		
		System.out.println("\nTest MyPinard\n");
		showAsserted(base, WINE_NS + "MyPinard");
		showInferred(inf, WINE_NS + "MyPinard");
		System.out.println("\nTest Validity of MyPinard finished ");
		checkValidity(inf); // OK
		
		// Instantiation des relations
		OntProperty locatedInProperty = base.createObjectProperty(WINE_NS + "locatedIn");
		OntProperty adjacentRegionProperty = base.createObjectProperty(WINE_NS + "adjacentRegion");
		OntProperty courseProperty = base.createObjectProperty(WINE_NS + "course");
		OntProperty hasDrinkProperty = base.createObjectProperty(WINE_NS + "hasDrink");
		OntProperty hasFoodProperty = base.createObjectProperty(WINE_NS + "hasFood");
		OntProperty hasMakerProperty = base.createObjectProperty(WINE_NS + "hasMaker");
		OntProperty hasFlavorProperty = base.createObjectProperty(WINE_NS + "hasFlavor");
		OntProperty hasBodyProperty = base.createObjectProperty(WINE_NS + "hasBody");
		OntProperty hasColorProperty = base.createObjectProperty(WINE_NS + "hasColor");
		OntProperty hasSugarProperty = base.createObjectProperty(WINE_NS + "hasSugar");
		OntProperty hasVintageYearProperty = base.createObjectProperty(WINE_NS + "hasVintageYear");
		OntProperty hasWineDescriptorProperty = base.createObjectProperty(WINE_NS + "hasWineDescriptor");
		OntProperty madeFromFruitProperty = base.createObjectProperty(WINE_NS + "madeFromFruit");
		OntProperty madeFromGrapeProperty = base.createObjectProperty(WINE_NS + "madeFromGrape");
		OntProperty madeIntoWineProperty = base.createObjectProperty(WINE_NS + "madeIntoWine");
		OntProperty producesWineProperty = base.createObjectProperty(WINE_NS + "producesWine");
						
	//les assertions
		System.out.println("\n----Assertions----\n");
		for (Iterator<Resource> i = EtienneVin.listRDFTypes(true); i.hasNext();)
	{
		System.out.println(EtienneVin.getURI()+" is asserted in class "+ i.next() );
	}	
	//on va lister ce qui a �t� d�duit ou inferr� par le syst�me
	System.out.println("\n----Inf�rences----\n");
	EtienneVin= inf.getIndividual(WINE_NS + "MyPinard");
	for (Iterator<Resource> i = EtienneVin.listRDFTypes(true); i.hasNext();)
	System.out.println(EtienneVin.getURI()+" is inferred to be in class "+ i.next() );
		}
	private static void checkValidity(OntModel inf) {
	// TODO Auto-generated method stub
	
	}
	private static void showAsserted(OntModel base, String string) {
		// TODO Auto-generated method stub

	}
	private static void showInferred(OntModel inf, String string) {
		// TODO Auto-generated method stub
	
	}
	
	}
