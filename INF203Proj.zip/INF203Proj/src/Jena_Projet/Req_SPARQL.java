package Jena_Projet;

import java.util.Date;
import java.util.Iterator;
import org.apache.jena.ontology.Individual;
import org.apache.jena.ontology.OntClass;
import org.apache.jena.ontology.OntModel;
import org.apache.jena.ontology.OntModelSpec;
import org.apache.jena.ontology.OntProperty;
import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.ResultSet;
import org.apache.jena.query.ResultSetFormatter;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Resource;
import org.apache.jena.reasoner.ValidityReport;
import org.apache.jena.util.FileManager;
import org.apache.jena.vocabulary.OWL;
import org.apache.jena.vocabulary.RDFS;
import org.apache.log4j.*;
import org.apache.log4j.varia.NullAppender;


public class Req_SPARQL {
	
		public static void main(String[] args)
				
		{
			System.out.println("D�but : " + new Date());
			new Req_SPARQL().go();
			System.out.println("Fin : " + new Date());
			
			//mise en place du fichier log4j.properties pour �viter le message d'erreur
			org.apache.log4j.BasicConfigurator.configure(new NullAppender());	
		}
		
		public static final String	SOURCE		= "./Data/";
		public static final String	CANCER_NS	= "http://www.ime202.isped/notifCancer#";

		public void go()
		{
			OntModel m = getModel();
			loadData(m);
		 	String prefix = "prefix notifCancer: <" + CANCER_NS + ">\n" + "prefix rdfs: <"
			+ RDFS.getURI() + ">\n" + "prefix owl: <" + OWL.getURI() + ">\n";
		 
			// Anc�tres de notifCancer:Lip et Palate
			showQuery(m, prefix
					+ "SELECT ?o " + "WHERE { "
					+ " notifCancer:Lip rdfs:subClassOf* ?o . "
					+ " notifCancer:Palate rdfs:subClassOf* ?o ."
					+ " FILTER ( ! isBlank(?o) ) " + "} ");
		 
			//  Anc�tres communs entre Hypopharynx et Gum
			showQuery(m, prefix
					+ "SELECT ?o " + "WHERE { "
					+ " notifCancer:Hypopharynx rdfs:subClassOf* ?o . "
					+ " notifCancer:Gum rdfs:subClassOf* ?o . "
					+ " FILTER ( ! isBlank(?o) ) " + "} ");
		}
		 
		protected OntModel getModel()
		{
			// OWL_MEM
			return ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
		}
		 
		protected void loadData(Model m)
		{
			FileManager.get().readModel(m, SOURCE + "jet1.owl");
		}
		 		protected void showQuery(Model m, String q)
		{
			Query query = QueryFactory.create(q);
			QueryExecution qexec = QueryExecutionFactory.create(query, m);
			try
			{
				ResultSet results = qexec.execSelect();
				ResultSetFormatter.out(results, m);
			}
			finally
			{
				qexec.close();
			}
		 		}
}